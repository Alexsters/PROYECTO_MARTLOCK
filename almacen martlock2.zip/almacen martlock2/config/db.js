const mysql = require('mysql');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // replace with your MySQL username
    password: '', // replace with your MySQL password
    database: 'almacenmartlock'
});

db.connect((err) => {
    if (err) {
        console.error('Error al conectar base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos.');
});

module.exports = db;
