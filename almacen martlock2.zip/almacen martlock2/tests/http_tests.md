# HTTP Tests for CRUD Application

### Test for adding a new user
**POST** `http://localhost:3000/api/users`  
**Content-Type**: application/json  
```json
{
    "nombre": "Juan Pérez",
    "correo": "juan.perez@email.com",
    "contraseña": "password123",
    "rol": "cliente",
    "direccion_predeterminada": "Calle 123, Ciudad A"
}
```

### Test for getting a user by ID
**GET** `http://localhost:3000/api/users/1`

### Test for updating a user
**PUT** `http://localhost:3000/api/users/1`  
**Content-Type**: application/json  
```json
{
    "nombre": "Juan Pérez",
    "correo": "juan.perez@email.com",
    "contraseña": "newpassword123",
    "rol": "cliente",
    "direccion_predeterminada": "Calle 456, Ciudad A"
}
```

### Test for deleting a user
**DELETE** `http://localhost:3000/api/users/1`

---

### Test for adding a new product
**POST** `http://localhost:3000/api/products`  
**Content-Type**: application/json  
```json
{
    "nombre": "Laptop Gamer",
    "descripcion": "Laptop con procesador Intel i7, 16GB RAM, RTX 3060",
    "precio": 5000000,
    "stock": 10
}
```

### Test for getting a product by ID
**GET** `http://localhost:3000/api/products/1`

### Test for updating a product
**PUT** `http://localhost:3000/api/products/1`  
**Content-Type**: application/json  
```json
{
    "nombre": "Laptop Gamer",
    "descripcion": "Laptop con procesador Intel i7, 16GB RAM, RTX 3070",
    "precio": 5500000,
    "stock": 8
}
```

### Test for deleting a product
**DELETE** `http://localhost:3000/api/products/1`

---

### Test for adding a new order
**POST** `http://localhost:3000/api/orders`  
**Content-Type**: application/json  
```json
{
    "usuario_id": 1,
    "total": 5000000
}
```

### Test for getting an order by ID
**GET** `http://localhost:3000/api/orders/1`

### Test for updating an order
**PUT** `http://localhost:3000/api/orders/1`  
**Content-Type**: application/json  
```json
{
    "usuario_id": 1,
    "total": 5500000
}
```

### Test for deleting an order
**DELETE** `http://localhost:3000/api/orders/1`
