const db = require('../config/db');
const bcrypt = require('bcrypt');

// Create a new user
exports.createUser = (req, res) => {
    const { nombre, correo, contraseña, rol, direccion_predeterminada } = req.body;
    const hashedPassword = bcrypt.hashSync(contraseña, 10);
    const query = 'INSERT INTO usuario (nombre, correo, contraseña, rol, direccion_predeterminada) VALUES (?, ?, ?, ?, ?)';
    
    db.query(query, [nombre, correo, hashedPassword, rol, direccion_predeterminada], (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ error: 'un usuario ya usa este correo' });
            } else {
                console.error('Error al crear usuario:', err.message);
                return res.status(500).json({ error: err.message });
            }
        }
        console.log(`User created: ${nombre} (ID: ${result.insertId})`);
        res.status(201).json({ message: 'User creado', userId: result.insertId });
    });
};

exports.getAllUsers = (req, res) => {
    const query = 'SELECT * FROM usuario';
    
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al mostrar usuarios:', err.message);
            return res.status(500).json({ error: err.message });
        }
        console.log(`Users mostrados: ${results.length} usuarios encontrados.`);
        res.status(200).json(results);
    });
};

exports.getUser = (req, res) => {
    const userId = req.params.id;
    const query = 'SELECT * FROM usuario WHERE id = ?';
    
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error al mostrar usuario:', err.message);
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            console.log(`Usuario no encontrado: ID ${userId}`);
            return res.status(404).json({ message: 'usuario no encontrado' });
        }
        console.log(`Usuario encontrado: ${results[0].nombre} (ID: ${userId})`);
        res.status(200).json(results[0]);
    });
};

exports.loginUser = (req, res) => {
    const { correo, contraseña } = req.body;
    const query = 'SELECT * FROM usuario WHERE correo = ?';
    
    db.query(query, [correo], (err, results) => {
        if (err) {
            console.error('Error retrieving user:', err.message);
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            console.log(`User not found: Email ${correo}`);
            return res.status(404).json({ message: 'Usuario no encontrado' });
        }
        
        const user = results[0];
        const passwordMatch = bcrypt.compareSync(contraseña, user.contraseña);
        
        if (!passwordMatch) {
            console.log(`Invalid password for user: Email ${correo}`);
            return res.status(401).json({ message: 'contraseña invalida' });
        }
        
        console.log(`User logged in: ${user.nombre} (Email: ${correo})`);
        res.status(200).json({ message: 'bienvenido', userId: user.id });
    });
};
exports.updateUser = (req, res) => {
    const userId = req.params.id;
    const { nombre, correo, contraseña, rol, direccion_predeterminada } = req.body;
    const hashedPassword = contraseña ? bcrypt.hashSync(contraseña, 10) : undefined;
    const query = 'UPDATE usuario SET nombre = ?, correo = ?, contraseña = ?, rol = ?, direccion_predeterminada = ? WHERE id = ?';
    
    db.query(query, [nombre, correo, hashedPassword, rol, direccion_predeterminada, userId], (err, result) => {
        if (err) {
            console.error('Error actualizando usuario:', err.message);
            return res.status(500).json({ error: err.message });
        }
        console.log(`User updated: ID ${userId}`);
        res.status(200).json({ message: 'Usuario actualizado' });
    });
};

// Delete user by ID
exports.deleteUser = (req, res) => {
    const userId = req.params.id;
    const query = 'DELETE FROM usuario WHERE id = ?';
    
    db.query(query, [userId], (err, result) => {
        if (err) {
            console.error('Error al eliminar usuario:', err.message);
            return res.status(500).json({ error: err.message });
        }
        console.log(`User deleted: ID ${userId}`);
        res.status(200).json({ message: 'Usuario eliminado' });
    });
};
