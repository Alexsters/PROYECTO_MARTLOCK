const db = require('../config/db');

// Create a new product
exports.createProduct = (req, res) => {
    const { nombre, descripcion, precio, stock } = req.body;
    const query = 'INSERT INTO producto (nombre, descripcion, precio, stock) VALUES (?, ?, ?, ?)';
    
    db.query(query, [nombre, descripcion, precio, stock], (err, result) => {
        if (err) {
            console.error('Error creating product:', err.message);
            return res.status(500).json({ error: err.message });
        }
        console.log(`Product created: ${nombre} (ID: ${result.insertId})`);
        res.status(201).json({ message: 'Product created successfully', productId: result.insertId });
    });
};

// Get product by ID
exports.getProduct = (req, res) => {
    const productId = req.params.id;
    const query = 'SELECT * FROM producto WHERE id = ?';
    
    db.query(query, [productId], (err, results) => {
        if (err) {
            console.error('Error retrieving product:', err.message);
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            console.log(`Product not found: ID ${productId}`);
            return res.status(404).json({ message: 'Product not found' });
        }
        console.log(`Product retrieved: ${results[0].nombre} (ID: ${productId})`);
        res.status(200).json(results[0]);
    });
};

// Update product by ID
exports.updateProduct = (req, res) => {
    const productId = req.params.id;
    const { nombre, descripcion, precio, stock } = req.body;
    const query = 'UPDATE producto SET nombre = ?, descripcion = ?, precio = ?, stock = ? WHERE id = ?';
    
    db.query(query, [nombre, descripcion, precio, stock, productId], (err, result) => {
        if (err) {
            console.error('Error updating product:', err.message);
            return res.status(500).json({ error: err.message });
        }
        console.log(`Product updated: ID ${productId}`);
        res.status(200).json({ message: 'Product updated successfully' });
    });
};

// Delete product by ID
exports.deleteProduct = (req, res) => {
    const productId = req.params.id;
    const query = 'DELETE FROM producto WHERE id = ?';
    
    db.query(query, [productId], (err, result) => {
        if (err) {
            console.error('Error deleting product:', err.message);
            return res.status(500).json({ error: err.message });
        }
        console.log(`Product deleted: ID ${productId}`);
        res.status(200).json({ message: 'Product deleted successfully' });
    });
};
