const db = require('../config/db');

// Create a new order
exports.createOrder = (req, res) => {
    const { usuario_id, total } = req.body;
    const query = 'INSERT INTO venta (usuario_id, total) VALUES (?, ?)';
    
    db.query(query, [usuario_id, total], (err, result) => {
        if (err) {
            console.error('Error creating order:', err.message);
            return res.status(500).json({ error: err.message });
        }
        console.log(`Order created: User ID ${usuario_id} (Order ID: ${result.insertId})`);
        res.status(201).json({ message: 'Order created successfully', orderId: result.insertId });
    });
};

// Get order by ID
exports.getOrder = (req, res) => {
    const orderId = req.params.id;
    const query = 'SELECT * FROM venta WHERE id = ?';
    
    db.query(query, [orderId], (err, results) => {
        if (err) {
            console.error('Error retrieving order:', err.message);
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            console.log(`Order not found: ID ${orderId}`);
            return res.status(404).json({ message: 'Order not found' });
        }
        console.log(`Order retrieved: ID ${orderId}`);
        res.status(200).json(results[0]);
    });
};

// Update order by ID
exports.updateOrder = (req, res) => {
    const orderId = req.params.id;
    const { usuario_id, total } = req.body;
    const query = 'UPDATE venta SET usuario_id = ?, total = ? WHERE id = ?';
    
    db.query(query, [usuario_id, total, orderId], (err, result) => {
        if (err) {
            console.error('Error updating order:', err.message);
            return res.status(500).json({ error: err.message });
        }
        console.log(`Order updated: ID ${orderId}`);
        res.status(200).json({ message: 'Order updated successfully' });
    });
};

// Delete order by ID
exports.deleteOrder = (req, res) => {
    const orderId = req.params.id;
    const query = 'DELETE FROM venta WHERE id = ?';
    
    db.query(query, [orderId], (err, result) => {
        if (err) {
            console.error('Error deleting order:', err.message);
            return res.status(500).json({ error: err.message });
        }
        console.log(`Order deleted: ID ${orderId}`);
        res.status(200).json({ message: 'Order deleted successfully' });
    });
};
