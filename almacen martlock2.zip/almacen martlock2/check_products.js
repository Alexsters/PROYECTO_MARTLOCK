const db = require('./config/db');

db.query('SELECT * FROM producto;', (err, results) => {
    if (err) {
        console.error('Error retrieving products:', err.message);
        return;
    }
    console.log('Products:', results);
    db.end();
});
